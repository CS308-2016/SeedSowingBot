2016 - CS308  Group 23 : Project README 
================================================ 
 
Group Info: 
------------ 
Harish 		(120050038)
Venkatesh 	(120050039)
Akshay 		(120050062)
Vinay 		(120050063)


 
Project Description 
------------------- 
 
In this project we aim to build a bot which automates sowing seeds in rooftop farming with which we can dig soil at regular intervals and then sow the seeds. This is aimed to reduce lot of manual labour in digging and sowing of seeds.

 
Technologies Used 
------------------- 
 
Remove the items that do no apply to your project and keep the remaining ones. 
 
+   Embedded C 
+   Xbee
    
Demonstration Video 
=========================  
[Instructions for installing software]
https://www.youtube.com/watch?v=_kmcXG4oLzQ&feature=youtu.be

Transcript for the screen cast video provided "screen_cast_transcript.txt"

[Project Demo]
https://www.youtube.com/watch?v=FO6eeObxwSs&feature=youtu.be


References 
=========== 
 
[Reference for code] 
https://drive.google.com/folderview?id=0BwLmQGS-3ITBQTZ0UUFHelpQT1k&usp=sharing&tid=0BwLmQGS-3ITBdzE2dXo5TXF4U0E

[Reference for Xbee setup]
https://github.com/eyantra/eYSIP2014_Communication_Module_Interfacing/blob/master/1.Zigbee/2.Network%20modes/1.unicast/Unicast_manual.pdf

[Reference for Serial Communication]
https://github.com/eyantra/eYSIP2014_Communication_Module_Interfacing
