Project Name:

Team Members:
1. Harish 		(120050038)
2. Venkatesh 	(120050039)
3. Akshay 		(120050062)
4. Vinay 		(120050063)

Project Description:

In this project we aim to build a bot which automates sowing seeds in rooftop farming with which we can dig soil at regular intervals and then sow the seeds. This is aimed to reduce lot of manual labour in digging and sowing of seeds.

